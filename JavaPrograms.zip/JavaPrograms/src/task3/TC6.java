package task3;

import java.util.Scanner;

public class TC6 {
//Write a�Java Program to Remove All Whitespaces from a String�
	public static void main(String[] args) {
		// TODO Auto-generated method stub


		String str;
		Scanner sc = new Scanner(System.in);
	 
		System.out.print(" Please Enter a sentance : ");
		str= "This is be tter";
		
	   String str1=str.replaceAll(" ", "");
	   System.out.println(str1);
		}
	}


