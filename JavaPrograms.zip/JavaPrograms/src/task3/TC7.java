package task3;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TC7 {
//7. Write a�Java Program to Convert String to Date�
	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub

		
		String str="27-Nov-2020";
		Date date1=new SimpleDateFormat("dd-MMM-yyyy").parse(str);
		System.out.println(date1);
	}

}
