package task2;

public class TC8 {
//Write a�Java Program to Concatenate Two Arrays�
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  String a[][]={{"a","b","c"},{"d","e","f"},{"g","h","i"}};
		  String b[][]={{"j","k","l"},{"m","n","o"},{"p","q","r"}};
		  String c[][]=new String[3][3];
		  for(int i = 0;i<3;i++){
		         for(int j = 0;j<3;j++){
		            c[i][j] = a[i][j]+b[i][j];
		            System.out.print(c[i][j]+" ");
		         }
		         System.out.println();
		      }
		   }
	}


