package task2;

public class TC9 {
//9. Write a�Java Program to Convert Character to String and Vice-Versa�
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		        char ch = 'c';
		        String st = Character.toString(ch);
		        // Alternatively
		        // st = String.valueOf(ch);

		        System.out.println("The string is: " + st);
		       String st1 = String.valueOf(ch);
		        System.out.println("The character is: " + st1);
		    }
		}
