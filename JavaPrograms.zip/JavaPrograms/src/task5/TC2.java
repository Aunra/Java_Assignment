package task5;

import java.util.Scanner;

public class TC2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


			// TODO Auto-generated method stub
	         int arr[]=new int[5];
	    int temp=Integer.MIN_VALUE;
	    for (int i=0;i<5;i++) {
	    	Scanner scan=new Scanner(System.in);
	         arr[i]=scan.nextInt();
	         
	    }
	    for(int i=0;i<5;i++) {
	    	 if(arr[i]>temp) {
	    	temp=arr[i];
	    }
	   	 
	      }
	    System.out.println(temp);
		}

}
