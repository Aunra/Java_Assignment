package task5;

public class TC6 {

	public static void main(String[] args) {
	
        int N = 1010; 
  
        // Function Call 
        System.out.println(isBinaryNumber(N)); 
    } 
	 public static boolean isBinaryNumber(int num) 
	    { 
 if (num == 0 || num == 1
     || num < 0) { 
     return false; 
 } 


 while (num != 0) { 

     if (num % 10 > 1) { 
         return false; 
     } 
     num = num / 10; 
 } 
 return true; 
} 

}
