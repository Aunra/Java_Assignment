package task1;

import java.util.Scanner;

public class TC4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		 
		System.out.print(" Please Enter Number of elements in an array : ");
		int n = sc.nextInt();
		  { 
		        if (isPowerOfTwo(n)) 
		            System.out.println("Yes"); 
		        else
		            System.out.println("No"); 
		 
		    } 
		
	}
	public static boolean isPowerOfTwo(int n) {
		if (n == 0) 
            return false; 
          
        while (n != 1) 
        { 
            if (n % 2 != 0) 
                return false; 
            n = n / 2; 
        } 
        return true; 
	}

}
