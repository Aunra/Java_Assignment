package task1;

import java.util.Scanner;

public class TC1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
		String Reverse ="";
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a word");
		String a= in.nextLine();
		int na=a.length();
		
		for (int i=na-1;i>=0;i--)
			
			Reverse=Reverse+ a.charAt(i);
			System.out.println(Reverse);
			
	}

}
